App.info({
  "id": "EventSpider.Dev",
  "version": "0.0.2",
  "name": "EventSpider"
});

App.accessRule('*');

App.launchScreens({
  'android_ldpi_portrait': 'public/openscreen.9.png',
  'android_ldpi_landscape': 'public/openscreen.9.png',
  'android_mdpi_portrait': 'public/openscreen.9.png',
  'android_mdpi_landscape': 'public/openscreen.9.png',
  'android_hdpi_portrait': 'public/openscreen.9.png',
  'android_hdpi_landscape': 'public/openscreen.9.png',
  'android_xhdpi_portrait': 'public/openscreen.9.png',
  'android_xhdpi_landscape': 'public/openscreen.9.png'
});
