(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Chart;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/chart_chart/packages/chart_chart.js                      //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['chart:chart'] = {
  Chart: Chart
};

})();

//# sourceMappingURL=chart_chart.js.map
