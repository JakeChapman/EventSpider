(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var LaunchScreen;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['launch-screen'] = {
  LaunchScreen: LaunchScreen
};

})();

//# sourceMappingURL=launch-screen.js.map
