(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['gfk:notifications'] = {};

})();

//# sourceMappingURL=gfk_notifications.js.map
