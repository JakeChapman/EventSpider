(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/settings.jsx                                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
//Collections                                                          //
Events = new Mongo.Collection("Events");                               // 2
Colleges = new Mongo.Collection("Colleges");                           // 3
Organizations = new Mongo.Collection("Organizations");                 // 4
                                                                       //
if (Meteor.isServer) {                                                 // 6
                                                                       //
  //    console.log(process.env.MONGO_URL);                            //
  //    console.log("Publishing Data");                                //
                                                                       //
  Meteor.publish('events', function () {                               // 11
    //console.log("Number of Documents on Server: " + Questions.find().count());
    events = Events.find({});                                          // 13
                                                                       //
    if (events) {                                                      // 15
      return events;                                                   // 16
    }                                                                  //
                                                                       //
    return this.ready();                                               // 19
  });                                                                  //
                                                                       //
  Meteor.publish('event', function (key) {                             // 22
    //console.log("Number of Documents on Server: " + Questions.find().count());
    event = Events.find({ title: key });                               // 24
                                                                       //
    console.log(key);                                                  // 26
    if (event) {                                                       // 27
      return event;                                                    // 28
    }                                                                  //
                                                                       //
    return this.ready();                                               // 31
  });                                                                  //
                                                                       //
  console.log("Publishing Data: Events done");                         // 34
                                                                       //
  Meteor.publish('colleges', function () {                             // 36
    colleges = Colleges.find({});                                      // 37
                                                                       //
    console.log("Number of Colleges: " + colleges.count());            // 39
                                                                       //
    if (colleges) {                                                    // 41
      return colleges;                                                 // 42
    }                                                                  //
                                                                       //
    return this.ready();                                               // 45
  });                                                                  //
                                                                       //
  console.log("Publishing Data: Events, Colleges done--something");    // 48
                                                                       //
  Meteor.publish('organizations', function () {                        // 50
    console.log("Finding orgs");                                       // 51
    organizations = Organizations.find({});                            // 52
                                                                       //
    console.log("Number of organizations: " + organizations.count());  // 54
                                                                       //
    if (organizations) {                                               // 56
      return organizations;                                            // 57
    }                                                                  //
                                                                       //
    return this.ready();                                               // 60
  });                                                                  //
                                                                       //
  Meteor.publish('organization', function (key) {                      // 63
                                                                       //
    console.log(key);                                                  // 65
    organization = Organizations.find({ name: key });                  // 66
                                                                       //
    console.log("Number of organization: " + organization.count());    // 68
                                                                       //
    if (organization) {                                                // 70
      return organization;                                             // 71
    }                                                                  //
                                                                       //
    return this.ready();                                               // 74
  });                                                                  //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=settings.jsx.map
